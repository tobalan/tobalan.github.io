from __future__ import unicode_literals
_A6='plugin.video.jiotv'
_A5='inputstream.adaptive.license_key'
_A4='inputstream.adaptive.manifest_type'
_A3='inputstream.adaptive.stream_headers'
_A2='inputstream'
_A1='IsPlayable'
_A0='properties'
_z='keywords'
_y='starCast'
_x='episode_desc'
_w='description'
_v='showGenre'
_u='mediatype'
_t='episodeguide'
_s='tvshowtitle'
_r='originaltitle'
_q='Catchup'
_p='isCatchupAvailable'
_o='clearart'
_n='clearlogo'
_m='channel_name'
_l='/resources/lib/main:show_featured'
_k='utf-8'
_j='JioTV'
_i='mobile'
_h='mpd'
_g='end'
_f='begin'
_e='programId'
_d=' %I:%M %p ]   %a'
_c='    [ %I:%M %p -'
_b='enabled'
_a='addonid'
_Z='Addons.SetAddonEnabled'
_Y=False
_X='%Y%m%dT%H%M%S'
_W='episode_num'
_V='duration'
_U='director'
_T='episode'
_S='showtime'
_R='title'
_Q='info'
_P='endEpoch'
_O=True
_N='fanart'
_M='srno'
_L='logoUrl'
_K='params'
_J='showname'
_I='episodePoster'
_H=None
_G='thumb'
_F='art'
_E='startEpoch'
_D='icon'
_C='callback'
_B='label'
_A='channel_id'
from xbmcaddon import Addon
from xbmc import executebuiltin,log,LOGINFO
from xbmcgui import Dialog,DialogProgress
from codequick import Route,run,Listitem,Resolver,Script
from codequick.utils import keyboard
from codequick.script import Settings
from codequick.storage import PersistentDict
from resources.lib.utils import getTokenParams,getHeaders,isLoggedIn,login as ULogin,logout as ULogout,check_addon,sendOTPV2,get_local_ip,getChannelHeaders,quality_to_enum,_setup,kodi_rpc,Monitor,getCachedChannels,getCachedDictionary,cleanLocalCache,getFeatured,getCachedFilteredCategory,getCachedFilteredLang
from resources.lib.constants import GET_CHANNEL_URL,IMG_CATCHUP,PLAY_URL,IMG_CATCHUP_SHOWS,CATCHUP_SRC,M3U_SRC,EPG_SRC,M3U_CHANNEL,IMG_CONFIG,EPG_PATH
import urlquick
from uuid import uuid4
from urllib.parse import urlencode
import inputstreamhelper,json
from time import time,sleep
from datetime import datetime,timedelta,date
import m3u8,requests,gzip,xml.etree.ElementTree as ET,os
monitor=Monitor()
@Route.register
def root(plugin):C='mode';B='/resources/lib/main:show_tv';A='cms/TKSS_Carousal1.jpg';yield Listitem.from_dict(**{_B:'Featured',_F:{_G:IMG_CATCHUP_SHOWS+A,_D:IMG_CATCHUP_SHOWS+A,_N:IMG_CATCHUP_SHOWS+A},_C:Route.ref(_l)});yield Listitem.from_dict(**{_B:'Categories',_F:{_G:IMG_CATCHUP_SHOWS+A,_D:IMG_CATCHUP_SHOWS+A,_N:IMG_CATCHUP_SHOWS+A},_C:Route.ref(B),_K:{C:'cat'}});yield Listitem.from_dict(**{_B:'Languages',_F:{_G:IMG_CATCHUP_SHOWS+A,_D:IMG_CATCHUP_SHOWS+A,_N:IMG_CATCHUP_SHOWS+A},_C:Route.ref(B),_K:{C:'lang'}})
@Route.register
def show_tv(plugin,mode='cat'):
	if mode=='lang':D=getCachedFilteredLang();B=getCachedFilteredCategory(D)
	else:E=getCachedFilteredCategory();B=getCachedFilteredLang(E)
	for A in B:
		if A.get('channelIdForRedirect'):continue
		C=Listitem.from_dict(**{_B:A.get(_m),_F:{_G:IMG_CATCHUP+A.get(_L),_D:IMG_CATCHUP+A.get(_L),_N:IMG_CATCHUP+A.get(_L),_n:IMG_CATCHUP+A.get(_L),_o:IMG_CATCHUP+A.get(_L)},_C:play,_K:{_A:A.get(_A)}})
		if A.get(_p):C.context.container(show_epg,_q,0,A.get(_A))
		yield C
@Route.register
def show_featured(plugin,id=_H):
	G='showStatus';F='id';D='data'
	for C in getFeatured():
		if id:
			if int(C.get(F,0))==int(id):
				H=C.get(D,[])
				for A in H:
					B={_F:{_G:IMG_CATCHUP_SHOWS+A.get(_I,''),_D:IMG_CATCHUP_SHOWS+A.get(_I,''),_N:IMG_CATCHUP_SHOWS+A.get(_I,''),_o:IMG_CATCHUP+A.get(_L,''),_n:IMG_CATCHUP+A.get(_L,'')},_Q:{_r:A.get(_J),_s:A.get(_J),'genre':A.get(_v),'plot':A.get(_w),_t:A.get(_x),_T:0 if A.get(_W)==-1 else A.get(_W),'cast':A.get(_y,'').split(', '),_U:A.get(_U),_V:A.get(_V)*60,'tag':A.get(_z),_u:'movie'if A.get('channel_category_name')=='Movies'else _T}}
					if A.get(G)=='Now':B[_B]=B[_Q][_R]=A.get(_J,'')+' [COLOR red] [ LIVE ] [/COLOR]';B[_C]=play;B[_K]={_A:A.get(_A)};yield Listitem.from_dict(**B)
					elif A.get(G)=='future':E=datetime.fromtimestamp(int(A.get(_E,0)*0.001)).strftime(_c)+datetime.fromtimestamp(int(A.get(_P,0)*0.001)).strftime(_d);B[_B]=B[_Q][_R]=A.get(_J,'')+' [COLOR green]%s[/COLOR]'%E;B[_C]='';yield Listitem.from_dict(**B)
					elif A.get(G)=='catchup':E=datetime.fromtimestamp(int(A.get(_E,0)*0.001)).strftime(_c)+datetime.fromtimestamp(int(A.get(_P,0)*0.001)).strftime(_d);B[_B]=B[_Q][_R]=A.get(_J,'')+' [COLOR yellow]%s[/COLOR]'%E;B[_C]=play;B[_K]={_A:A.get(_A),_S:A.get(_S,'').replace(':',''),_M:datetime.fromtimestamp(int(A.get(_E,0)*0.001)).strftime('%Y%m%d'),_e:A.get(_M,''),_f:datetime.utcfromtimestamp(int(A.get(_E,0)*0.001)).strftime(_X),_g:datetime.utcfromtimestamp(int(A.get(_P,0)*0.001)).strftime(_X)};yield Listitem.from_dict(**B)
		else:yield Listitem.from_dict(**{_B:C.get('name'),_F:{_G:IMG_CATCHUP_SHOWS+C.get(D,[{}])[0].get(_I),_D:IMG_CATCHUP_SHOWS+C.get(D,[{}])[0].get(_I),_N:IMG_CATCHUP_SHOWS+C.get(D,[{}])[0].get(_I)},_C:Route.ref(_l),_K:{F:C.get(F)}})
@Route.register
def show_epg(plugin,day,channel_id):
	D=channel_id;F=urlquick.get(CATCHUP_SRC.format(day,D),max_age=-1).json();G=sorted(F['epg'],key=lambda show:show[_E],reverse=_Y);H='[COLOR red] [ LIVE ] [/COLOR]'
	for A in G:
		B=int(time()*1000)
		if not A['stbCatchupAvailable']or A[_E]>B:continue
		I=A[_E]<B and A[_P]>B;E='   '+H if I else datetime.fromtimestamp(int(A[_E]*0.001)).strftime(_c)+datetime.fromtimestamp(int(A[_P]*0.001)).strftime(_d);yield Listitem.from_dict(**{_B:A[_J]+E,_F:{_G:IMG_CATCHUP_SHOWS+A[_I],_D:IMG_CATCHUP_SHOWS+A[_I],_N:IMG_CATCHUP_SHOWS+A[_I]},_C:play,_Q:{_R:A[_J]+E,_r:A[_J],_s:A[_J],'genre':A[_v],'plot':A[_w],_t:A.get(_x),_T:0 if A[_W]==-1 else A[_W],'cast':A[_y].split(', '),_U:A[_U],_V:A[_V]*60,'tag':A[_z],_u:_T},_K:{_A:A.get(_A),_S:A.get(_S,'').replace(':',''),_M:datetime.fromtimestamp(int(A.get(_E,0)*0.001)).strftime('%Y%m%d'),_e:A.get(_M,''),_f:datetime.utcfromtimestamp(int(A.get(_E,0)*0.001)).strftime(_X),_g:datetime.utcfromtimestamp(int(A.get(_P,0)*0.001)).strftime(_X)}})
	if int(day)==0:
		for C in range(-1,-7,-1):J='Yesterday'if C==-1 else (date.today()+timedelta(days=C)).strftime('%A %d %B');yield Listitem.from_dict(**{_B:J,_C:Route.ref('/resources/lib/main:show_epg'),_K:{'day':C,_A:D}})
@Resolver.register
@isLoggedIn
def play_ex(plugin,dt=_H):
	G='default_logo';F='lUrl';E='drm';D='proto';A=dt;C=inputstreamhelper.Helper(A.get(D,_h),drm=A.get(E))
	if C.check_inputstream():
		H=A.get(F)and A.get(F).replace('{HEADERS}',urlencode(getHeaders())).replace('{TOKEN}',urlencode(getTokenParams()));B={}
		if A.get(G):B[_G]=B[_D]=IMG_CATCHUP+A.get(G)
		return Listitem().from_dict(**{_B:A.get(_B)or plugin._title,_F:B or _H,_C:A.get('pUrl'),_A0:{_A1:_O,_A2:C.inputstream_addon,_A3:A.get('hdrs'),_A4:A.get(D,_h),'inputstream.adaptive.license_type':A.get(E),_A5:H}})
@Resolver.register
@isLoggedIn
def play(plugin,channel_id,showtime=_H,srno=_H,programId=_H,begin=_H,end=_H):
	V='user-agent';U='__hdnea__';T='stream_type';N=showtime;M=channel_id;L='cookie';K='result';F='?';W=inputstreamhelper.Helper(_h,drm='com.widevine.alpha');X=W.check_inputstream()
	if not X:return
	A={_A:int(M),T:'Seek'};O=_Y
	if N and srno:O=_O;A[_S]=N;A[_M]=srno;A[T]=_q;A[_e]=programId;A[_f]=begin;A[_g]=end;Script.log(str(A),lvl=Script.INFO)
	C=getHeaders();C['channelid']=str(M);C[_M]=str(uuid4())if _M not in A else A[_M];Y=urlquick.post(GET_CHANNEL_URL,json=A,headers=getChannelHeaders(),max_age=-1);G=Y.json();H={};E=G.get(K,'').split(F)[0].split('/')[-1];H[_G]=H[_D]=IMG_CATCHUP+E.replace('.m3u8','.png');P=U+G.get(K,'').split(U)[-1];C[L]=P;B=G.get(K,'');Q=Settings.get_string('quality');R='adaptive'
	if Q=='Manual':R='ask-quality'
	else:
		I={};I[V]=C[V];I[L]=P;Z=urlquick.get(B,headers=I,max_age=-1,raise_for_status=_O);a=Z.text;D=m3u8.loads(a)
		if D.is_variant and(D.version is _H or D.version<7):
			S=quality_to_enum(Q,len(D.playlists))
			if O:
				J=D.playlists[S].uri
				if F in J:B=B.split(F)[0].replace(E,J)
				else:B=B.replace(E,J.split(F)[0])
				del C[L]
			else:B=B.replace(E,D.playlists[S].uri)
	Script.log(B,lvl=Script.INFO);return Listitem().from_dict(**{_B:plugin._title,_F:H,_C:B,_A0:{_A1:_O,_A2:'inputstream.adaptive','inputstream.adaptive.stream_selection_type':R,'inputstream.adaptive.chooser_resolution_secure_max':'4K',_A3:urlencode(C),_A4:'hls',_A5:'|'+urlencode(C)+'|R{SSM}|'}})
@Script.register
def login(plugin):
	G='headers';F='Login';C=Dialog().yesno(F,'Select Login Method',yeslabel='Keyboard',nolabel='WEB')
	if C==1:
		D=Dialog().yesno(F,'Select Login Type',yeslabel='OTP',nolabel='Password')
		if D==1:
			A=Settings.get_string(_i)
			if not A or len(A)!=10:A=Dialog().numeric(0,'Enter your Jio mobile number')
			E=sendOTPV2(A)
			if E:Script.notify('Login Error',E);return
			H=Dialog().numeric(0,'Enter OTP');ULogin(A,H,mode='otp')
		elif D==0:I=keyboard('Enter your Jio mobile number or email');J=keyboard('Enter your password',hidden=_O);ULogin(I,J)
	elif C==0:
		B=DialogProgress();B.create(_j,'Visit [B]http://%s:48996/[/B] to login'%get_local_ip())
		for K in range(120):
			sleep(1)
			with PersistentDict(G)as L:M=L.get(G)
			if M or B.iscanceled():break
			B.update(K)
		B.close()
@Script.register
def setmobile(plugin):A=_A6;B=Addon(A);C=Settings.get_string(_i);D=Dialog().numeric(0,'Update Jio mobile number',C);kodi_rpc(_Z,{_a:A,_b:_Y});B.setSetting(_i,D);kodi_rpc(_Z,{_a:A,_b:_O});monitor.waitForAbort(1);Script.notify('Jio number set','')
@Script.register
def applyall(plugin):A=_A6;kodi_rpc(_Z,{_a:A,_b:_Y});monitor.waitForAbort(1);kodi_rpc(_Z,{_a:A,_b:_O});monitor.waitForAbort(1);Script.notify('All settings applied','')
@Script.register
def logout(plugin):ULogout()
@Script.register
def m3ugen(plugin,notify='yes'):
	J='channelCategoryId';I='channelLanguageId';K=getCachedChannels();C=getCachedDictionary();D=C.get('channelCategoryMapping');E=C.get('languageIdMapping');F='#EXTM3U x-tvg-url="%s"'%EPG_SRC
	for (L,A) in enumerate(K):
		if str(A.get(I))not in E.keys():B='Extra'
		else:B=E[str(A.get(I))]
		if str(A.get(J))not in D.keys():G='Extragenre'
		else:G=D[str(A.get(J))]
		if not Settings.get_boolean(B):continue
		M=B+';'+G;N=PLAY_URL+'channel_id={0}'.format(A.get(_A));H=''
		if A.get(_p):H=' catchup="vod" catchup-source="{0}channel_id={1}&showtime={{H}}{{M}}{{S}}&srno={{Y}}{{m}}{{d}}&programId={{catchup-id}}" catchup-days="7"'.format(PLAY_URL,A.get(_A))
		F+=M3U_CHANNEL.format(tvg_id=A.get(_A),channel_name=A.get(_m),group_title=M,tvg_chno=int(A.get('channel_order',L))+1,tvg_logo=IMG_CATCHUP+A.get(_L,''),catchup=H,play_url=N)
	with open(M3U_SRC,'w+')as O:O.write(F.replace('\xa0',' ').encode(_k).decode(_k))
	if notify=='yes':Script.notify(_j,'Playlist updated.')
@Script.register
def epg_setup(plugin):
	H='Epg setup in progress';E='UTF-8';Script.notify('Please wait',H);A=DialogProgress();A.create(H);C=Settings.get_string('epgurl')
	if not C or len(C)<5:C='https://cdn.jsdelivr.net/gh/mitthu786/tvepg/epg.xml.gz'
	I={};J={};K=requests.request('GET',C,headers=J,data=I)
	with open(EPG_PATH,'wb')as B:B.write(K.content)
	A.update(20)
	with gzip.open(EPG_PATH,'rb')as B:L=B.read();M=L.decode(_k);F=ET.fromstring(M)
	A.update(30);A.update(35);A.update(45)
	for D in F.iterfind('.//programme'):N=D.find(_D);O=N.get('src');P=O.rsplit('/',1)[-1];Q=os.path.splitext(P)[0];D.set('catchup-id',Q);G=D.find(_R);G.text=G.text.strip()
	A.update(60);R='<?xml version="1.0" encoding="UTF-8"?>\n';S='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n';T=R.encode(E)+S.encode(E)+ET.tostring(F,encoding=E);U=gzip.compress(T);A.update(80)
	with open(EPG_PATH,'wb')as B:B.write(U)
	A.update(100);A.close();Script.notify(_j,'Epg generated')
@Script.register
def pvrsetup(plugin):
	D='true';C='0';executebuiltin('RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/m3ugen/)');B='pvr.iptvsimple'
	def A(id,value):
		A=value
		if Addon(B).getSetting(id)!=A:Addon(B).setSetting(id,A)
	if check_addon(B):A('m3uPathType',C);A('m3uPath',M3U_SRC);A('epgPathType','1');A('epgUrl',EPG_SRC);A('epgCache','false');A('useInputstreamAdaptiveforHls',D);A('catchupEnabled',D);A('catchupWatchEpgBeginBufferMins',C);A('catchupWatchEpgEndBufferMins',C)
	_setup(M3U_SRC,EPG_SRC)
@Script.register
def cleanup(plugin):urlquick.cache_cleanup(-1);cleanLocalCache();Script.notify('Cache Cleaned','')