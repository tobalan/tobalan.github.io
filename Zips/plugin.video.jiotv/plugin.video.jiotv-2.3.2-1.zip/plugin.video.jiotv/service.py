from resources.lib import proxy
𞠩=Exception
𐤁=True
𮑖=proxy.𮑖
from codequick import Script
𡕚=Script.DEBUG
𤦟=Script.log
from codequick.script import Settings
𨘣=Settings.get_boolean
from socketserver import ThreadingTCPServer
𑫘=ThreadingTCPServer.allow_reuse_address
import threading
𢇞=threading.Thread
from xbmc import Monitor,executebuiltin
from kodi_six import xbmcgui
ﰹ=xbmcgui.Dialog
def ﬨ(𐿭):
 try:
  𐿭.serve_forever()
 except 𞠩 as e:
  𤦟(e,lvl=𡕚)
  pass
𑫘=𐤁
ꤊ=48996
𐿭=ThreadingTCPServer(("",ꤊ),𮑖)
t=𢇞(target=ﬨ,args=(𐿭,))
t.setDaemon(𐤁)
t.start()
if not 𨘣("popup"):
 ﰹ().ok("JioTV Notification","Now you can create your custom playlist from BotAllen Dashboard. [CR]Find out more at [B]https://botallen.com/#dashboard[/B] [CR][CR]If you like this add-on then consider donating from [B]https://botallen.com/#donate[/B] [CR][CR]Github: [B]https://github.com/botallen/repository.botallen[/B] [CR]Discord: [B]https://botallen.com/discord[/B] [CR][CR][I]You can disable this popup from settings[/I]")
if 𨘣("m3ugen"):
 ﺩ("RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/m3ugen/?notify=no)")
ﱑ=Monitor()
while not ﱑ.abortRequested():
 if ﱑ.waitForAbort(10):
  𐿭.shutdown()
  𐿭.server_close()
  break
# Created by pyminifier (https://github.com/liftoff/pyminifier)
