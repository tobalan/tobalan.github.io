from resources.lib import main
𡋤=main.𡋤
if __name__=="__main__":
 𡋤()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
