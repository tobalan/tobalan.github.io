from __future__ import unicode_literals
טּ=Exception
飻=False
𞢙=None
𞺍=str
𐦒=int
𥿿=True
ﰁ=RuntimeError
ښ=min
𐠄=list
𤟼=open
import os
𪻕=os.listdir
덮=os.path
𐲔=os.stat
import urlquick
𐭲=urlquick.get
𓏪=urlquick.post
from uuid import uuid4
import base64
𮤯=base64.b64encode
import hashlib
𩑶=hashlib.md5
import time
𘝒=time.time
from functools import wraps
from distutils.version import LooseVersion
from codequick import Script
𤡇=Script.get_info
𐳍=Script.ERROR
𤿲=Script.INFO
𐡇=Script.log
뻒=Script.notify
from codequick.storage import PersistentDict
from xbmc import executebuiltin
from xbmcgui import Dialog,DialogProgress
from xbmcaddon import Addon
import xbmc
碁=xbmc.executebuiltin
ߧ=xbmc.executeJSONRPC
𪾘=xbmc.Monitor
import xbmcvfs
𗂺=xbmcvfs.copy
𪳹=xbmcvfs.delete
𤸧=xbmcvfs.exists
ٯ=xbmcvfs.translatePath
from contextlib import contextmanager
from collections import defaultdict
import socket
𐴇=socket.SOCK_DGRAM
𢛶=socket.AF_INET
ڼ=socket.socket
import json
ﺷ=json.dumps
ړ=json.loads
from resources.lib.constants import CHANNELS_SRC,DICTIONARY_URL,FEATURED_SRC
def ܩ():
 s=ڼ(𢛶,𐴇)
 s.settimeout(0)
 try:
  s.connect(("8.8.8.8",80))
  IP=s.getsockname()[0]
 except טּ:
  IP='127.0.0.1'
 finally:
  s.close()
 return IP
def 𧹄(func):
 @wraps(func)
 def 𢞙(*args,**kwargs):
  with PersistentDict("localdb")as db:
   𐤵=db.get("username")
   𐠧=db.get("password")
   ﰩ=db.get("headers")
   𪸎=db.get("exp",0)
  if ﰩ and 𪸎>𘝒():
   return func(*args,**kwargs)
  elif 𐤵 and 𐠧:
   𐼺(𐤵,𐠧)
   return func(*args,**kwargs)
  elif ﰩ and 𪸎<𘝒():
   뻒("Login Error","Session expired. Please login again")
   𫋴("RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/login/)")
   return 飻
  else:
   뻒("Login Error","You need to login with Jio Username and password to use this add-on")
   𫋴("RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/login/)")
   return 飻
 return 𢞙
def 𐼺(𐤵,𐠧,mode="unpw"):
 𒊵=𞢙
 if(mode=='otp'):
  ﰓ="+91"+𐤵
  𐽹={"number":𮤯(ﰓ.encode("ascii")).decode("ascii"),"otp":𐠧,"deviceInfo":{"consumptionDeviceName":"unknown sdk_google_atv_x86","info":{"type":"android","platform":{"name":"generic_x86"},"androidId":𞺍(uuid4())}}}
  𒊵=𓏪("https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/verify",json=𐽹,headers={"User-Agent":"okhttp/4.2.2","devicetype":"phone","os":"android","appname":"RJIL_JioTV"},max_age=-1,verify=飻,raise_for_status=飻).json()
 else:
  𭍠={"identifier":𐤵 if '@' in 𐤵 else "+91"+𐤵,"password":𐠧,"rememberUser":"T","upgradeAuth":"Y","returnSessionDetails":"T","deviceInfo":{"consumptionDeviceName":"ZUK Z1","info":{"type":"android","platform":{"name":"ham","version":"8.0.0"},"androidId":𞺍(uuid4())}}}
  𒊵=𓏪("https://api.jio.com/v3/dip/user/{0}/verify".format(mode),json=𭍠,headers={"User-Agent":"JioTV","x-api-key":"l7xx75e822925f184370b2e25170c5d5820a","Content-Type":"application/json"},max_age=-1,verify=飻,raise_for_status=飻).json()
 if 𒊵.get("ssoToken","")!="":
  賬={"ssotoken":𒊵.get("ssoToken"),"userid":𒊵.get("sessionAttributes",{}).get("user",{}).get("uid"),"uniqueid":𒊵.get("sessionAttributes",{}).get("user",{}).get("unique"),"crmid":𒊵.get("sessionAttributes",{}).get("user",{}).get("subscriberId"),"subscriberid":𒊵.get("sessionAttributes",{}).get("user",{}).get("subscriberId"),}
  ﰩ={"deviceId":𞺍(uuid4()),"devicetype":"phone","os":"android","osversion":"9","user-agent":"plaYtv/7.0.8 (Linux;Android 9) ExoPlayerLib/2.11.7","usergroup":"tvYR7NSNn7rymo3F","versioncode":"289","dm":"ZUK ZUK Z1"}
  ﰩ.update(賬)
  with PersistentDict("localdb")as db:
   db["headers"]=ﰩ
   db["exp"]=𘝒()+31536000
   if mode=="unpw":
    db["username"]=𐤵
    db["password"]=𐠧
  뻒("Login Success","")
  return 𞢙
 else:
  𐡇(𒊵,lvl=𤿲)
  𐿱=𒊵.get("message","Unknow Error")
  뻒("Login Failed",𐿱)
  return 𐿱
def 𥒍(ﰓ):
 if "+91" not in ﰓ:
  ﰓ="+91"+ﰓ
 𭍠={"number":𮤯(ﰓ.encode("ascii")).decode("ascii")}
 𐡇(𭍠,lvl=𐳍)
 𒊵=𓏪("https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/send",json=𭍠,headers={"user-agent":"okhttp/4.2.2","os":"android","host":"jiotvapi.media.jio.com","devicetype":"phone","appname":"RJIL_JioTV"},max_age=-1,verify=飻,raise_for_status=飻)
 if 𒊵.status_code!=204:
  return 𒊵.json().get("errors",[{}])[-1].get("message")
 return 𞢙
def ک():
 with PersistentDict("localdb")as db:
  del db["headers"]
 뻒("You\'ve been logged out","")
def 𐳠():
 with PersistentDict("localdb")as db:
  return db.get("headers",飻)
def 𧭕():
 with PersistentDict("localdb")as db:
  𗲗=db.get("channelList",飻)
  if not 𗲗:
   try:
    𞤠=𐭲(CHANNELS_SRC).json().get("result")
    db["channelList"]=𞤠
   except:
    뻒("Connection error ","Retry after sometime")
  return db.get("channelList",飻)
def 𐩲():
 with PersistentDict("localdb")as db:
  玍=db.get("dictionary",飻)
  if not 玍:
   try:
    r=𐭲(DICTIONARY_URL).text.encode('utf8')[3:].decode('utf8')
    db["dictionary"]=ړ(r)
   except:
    뻒("Connection error ","Retry after sometime")
  return db.get("dictionary",飻)
def 蕍():
 try:
  𒊵=𐭲(FEATURED_SRC,headers={"usergroup":"tvYR7NSNn7rymo3F","os":"android","devicetype":"phone","versionCode":"290"},max_age=-1).json()
  return 𒊵.get("featuredNewData",[])
 except:
  뻒("Connection error ","Retry after sometime")
def 𞄔():
 with PersistentDict("localdb")as db:
  del db["channelList"]
  del db["dictionary"]
def ﶉ():
 ﰩ=𐳠()
 return{'ssotoken':ﰩ['ssotoken'],'userId':ﰩ['userid'],'uniqueId':ﰩ['uniqueid'],'crmid':ﰩ['crmid'],'user-agent':'plaYtv/7.0.8 (Linux;Android 9) ExoPlayerLib/2.11.7','deviceid':ﰩ['deviceId'],'devicetype':'phone','os':'android','osversion':'9',}
def 𠇴():
 def 丫(x):return 𮤯(𩑶(x.encode()).digest()).decode().replace('=','').replace('+','-').replace('/','_').replace('\r','').replace('\n','')
 𠁤=𞺍(𐦒(𘝒()+(3600*9.2)))
 ﯥ=丫("cutibeau2ic9p-O_v1qIyd6E-rf8_gEOQ"+𠁤)
 return{"jct":ﯥ,"pxe":𠁤,"st":"9p-O_v1qIyd6E-rf8_gEOQ"}
def 㕝(𥾦,minVersion=飻):
 try:
  ڃ=𤡇("version",𥾦)
  if minVersion and LooseVersion(ڃ)<LooseVersion(minVersion):
   𐡇('{addon} {curVersion} doesn\'t setisfy required version {minVersion}.'.format(addon=𥾦,curVersion=ڃ,minVersion=minVersion))
   ﱊ().ok("Error","{minVersion} version of {addon} is required to play this content.".format(addon=𥾦,minVersion=minVersion))
   return 飻
  return 𥿿
 except ﰁ:
  𐡇('{addon} is not installed.'.format(addon=𥾦))
  if not ᆈ(𥾦):
   ﱊ().ok("Error","[B]{addon}[/B] is missing on your Kodi install. This add-on is required to play this content.".format(addon=𥾦))
   return 飻
  return 𥿿
def ᆈ(𥾦):
 try:
  𫋴('InstallAddon({})'.format(𥾦),wait=𥿿)
  תּ=𤡇("version",𥾦)
  𐡇('{addon} {version} add-on installed from repo.'.format(addon=𥾦,version=תּ))
  return 𥿿
 except ﰁ:
  𐡇('{addon} add-on not installed.'.format(addon=𥾦))
  return 飻
def 𐭨(quality_str,arr_len):
 𗽎={'Best':arr_len-1,'High':4,'Medium+':3,'Medium':2,'Low':1,'Lowest':0,}
 if quality_str in 𗽎:
  return ښ(𗽎[quality_str],arr_len-1)
 return 0
𐼓=defaultdict(𐠄)
𐼴=defaultdict(𐦒)
def 𘝺(䉞,*args,**kwargs):
 if 𐼴[䉞]>0:
  𐼴[䉞]-=1
  return
 for f in 𐼓.get(䉞,[]):
  f(*args,**kwargs)
class ﭕ(𪾘):
 def 䟫(self):
  𘝺('on_settings_changed')
𣧢=ﭕ()
def 𞤔(method,params=𞢙,raise_on_error=飻):
 try:
  ꗽ={'jsonrpc':'2.0','id':1}
  ꗽ.update({'method':method})
  if params:
   ꗽ['params']=params
  酢=ړ(ߧ(ﺷ(ꗽ)))
  if 'error' in 酢:
   raise טּ('Kodi RPC "{} {}" returned Error: "{}"'.format(method,params or '',酢['error'].get('message')))
  return 酢['result']
 except טּ as e:
  if raise_on_error:
   raise
  else:
   return{}
def 𬩙(key,value):
 return 𞤔('Settings.SetSettingValue',{'setting':key,'value':value})
def 𩰎(path_a,path_b):
 if path_a.lower().strip()==path_b.lower().strip():
  return 𥿿
 𐴂=𐲔(path_a)if 덮.isfile(path_a)else 𞢙
 if not 𐴂:
  return 飻
 𞡐=𐲔(path_b)if 덮.isfile(path_b)else 𞢙
 if not 𞡐:
  return 飻
 return(𐴂.st_dev==𞡐.st_dev)and(𐴂.st_ino==𞡐.st_ino)and(𐴂.st_mtime==𞡐.st_mtime)
def 칫(𐳂,𞤴,del_src=飻):
 𐳂=ٯ(𐳂)
 𞤴=ٯ(𞤴)
 if not 𤸧(𐳂)or 𩰎(𐳂,𞤴):
  return
 if 𤸧(𞤴):
  if 𪳹(𞤴):
   𐡇('Deleted: {}'.format(𞤴))
  else:
   𐡇('Failed to delete: {}'.format(𞤴))
 if 𗂺(𐳂,𞤴):
  𐡇('Copied: {} > {}'.format(𐳂,𞤴))
 else:
  𐡇('Failed to copy: {} > {}'.format(𐳂,𞤴))
 if del_src:
  𪳹(𐳂)
@contextmanager
def 𐾿():
 碁('ActivateWindow(busydialognocancel)')
 try:
  yield
 finally:
  碁('Dialog.Close(busydialognocancel)')
def 𧫲(m3uPath,epgUrl):
 𨷙=DialogProgress()
 𨷙.create('PVR Setup in progress')
 ࢹ='pvr.iptvsimple'
 𤱡=Addon(ࢹ)
 ର=𤱡.getAddonInfo('name')
 餜=ٯ(𤱡.getAddonInfo('profile'))
 𐡲=덮.join(餜,'instance-settings-91.xml')
 𞤔('Addons.SetAddonEnabled',{'addonid':ࢹ,'enabled':飻})
 𨷙.update(10)
 if LooseVersion(𤱡.getAddonInfo('version'))>=LooseVersion('20.8.0'):
  𪳹(𐡲)
  for 𞤅 in 𪻕(餜):
   if 𞤅.startswith('instance-settings-')and 𞤅.endswith('.xml'):
    ﴅ=덮.join(餜,𞤅)
    with 𤟼(ﴅ)as f:
     酢=f.read()
    if 'id="m3uPath">{}</setting>'.format(m3uPath)in 酢 or 'id="epgUrl">{}</setting>'.format(epgUrl)in 酢:
     𪳹(덮.join(餜,ﴅ))
    else:
     칫(ﴅ,ﴅ+'.bu',del_src=𥿿)
  𨷙.update(25)
  𞤔('Addons.SetAddonEnabled',{'addonid':ࢹ,'enabled':𥿿})
  while not 덮.exists(덮.join(餜,'instance-settings-1.xml')):
   𣧢.waitForAbort(1)
  𞤔('Addons.SetAddonEnabled',{'addonid':ࢹ,'enabled':飻})
  𣧢.waitForAbort(1)
  칫(덮.join(餜,'instance-settings-1.xml'),𐡲,del_src=𥿿)
  𨷙.update(35)
  with 𤟼(𐡲,'r')as f:
   酢=f.read()
  with 𤟼(𐡲,'w')as f:
   f.write(酢.replace('Migrated Add-on Config',ର))
  𨷙.update(50)
  for 𞤅 in 𪻕(餜):
   if 𞤅.endswith('.bu'):
    칫(덮.join(餜,𞤅),덮.join(餜,𞤅[:-3]),del_src=𥿿)
  𞤔('Addons.SetAddonEnabled',{'addonid':ࢹ,'enabled':𥿿})
  𨷙.update(70)
 else:
  𞤔('Addons.SetAddonEnabled',{'addonid':ࢹ,'enabled':𥿿})
  𨷙.update(70)
 𬩙('epg.futuredaystodisplay',7)
 𬩙('pvrmanager.syncchannelgroups',𥿿)
 𬩙('pvrmanager.preselectplayingchannel',𥿿)
 𬩙('pvrmanager.backendchannelorder',𥿿)
 𬩙('pvrmanager.usebackendchannelnumbers',𥿿)
 𨷙.update(100)
 𨷙.close()
 뻒("IPTV setup","Epg and playlist updated")
 return 𥿿
# Created by pyminifier (https://github.com/liftoff/pyminifier)
