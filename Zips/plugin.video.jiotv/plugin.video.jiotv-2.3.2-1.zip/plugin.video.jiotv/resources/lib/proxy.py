from __future__ import unicode_literals
𤟼=open
𭩳=IOError
𞢙=None
𞺍=str
𘬜=bytes
𐦒=int
טּ=Exception
from http.server import SimpleHTTPRequestHandler
import os
𞸹=os.fstat
덮=os.path
from urllib.parse import parse_qs,urlparse
from xbmcvfs import translatePath
import xbmcaddon
𭭗=xbmcaddon.Addon
from resources.lib.utils import login,sendOTPV2
from codequick import Script
𐳍=Script.ERROR
𤿲=Script.INFO
𐡇=Script.log
ٱ=𭭗()
𗴝=ٱ.getAddonInfo("path")
class 𫿧(SimpleHTTPRequestHandler):
 def 𫲪(燏):
  ꄴ=urlparse(燏.path).path
  if ꄴ=="/":
   燏.send_response(200)
   𣳫=덮.join(translatePath(𗴝),"resources","login.html")
   try:
    f=𤟼(𣳫,'rb')
   except 𭩳:
    燏.send_error(404,"File not found")
    return 𞢙
   燏.send_header("Content-type","text/html")
   fs=𞸹(f.fileno())
   燏.send_header("Content-Length",𞺍(fs.st_size))
   燏.end_headers()
   燏.wfile.write(𘬜(f.read()))
   f.close()
   return
  else:
   燏.send_error(404,"File not found")
 def ﴙ(燏):
  if 燏.path=="/login":
   𐾻=燏.rfile.read(𐦒(燏.headers['Content-Length']))
   qs=parse_qs(𐾻.decode('utf-8'))
   䔧=𞢙
   𐡇(qs,lvl=𤿲)
   try:
    if qs.get("type")[0]=="password":
     䔧=login(qs.get("username")[0],qs.get("password")[0])
    elif qs.get("type")[0]=="otp":
     𐨗=qs.get("mobile")[0]
     if qs.get("otp"):
      䔧=login(𐨗,qs.get("otp")[0],mode="otp")
     else:
      䔧=sendOTPV2(𐨗)
    else:
     䔧="Invalid Type"
   except טּ as e:
    𐡇(e,lvl=𐳍)
    䔧=𞺍(e)
   if 䔧:
    ﰐ="/?error="+𞺍(䔧)
   elif qs.get("type")[0]=="otp" and qs.get("otp")is 𞢙:
    ﰐ="/?otpsent="+qs.get("mobile")[0]
   else:
    ﰐ="/?success"
   燏.send_response(302)
   燏.send_header('Location',ﰐ)
   燏.end_headers()
  else:
   燏.send_error(404,"File not found")
# Created by pyminifier (https://github.com/liftoff/pyminifier)
