from __future__ import unicode_literals
𞢙=None
𨝗=id
𐦒=int
𐠄=list
𞺍=str
飻=False
𐦭=filter
𣜤=sorted
𤨴=range
𥿿=True
𐤥=len
𬇄=enumerate
𤟼=open
from xbmcaddon import Addon
from xbmc import executebuiltin,log,LOGINFO
from xbmcgui import Dialog,DialogProgress
from codequick import Route,run,Listitem,Resolver,Script
뻒=Script.notify
𞢢=Script.register
𤿲=Script.INFO
𐡇=Script.log
ﶎ=Resolver.register
𮖢=Listitem.from_dict
ﳭ=Route.ref
ݐ=Route.register
from codequick.utils import keyboard
from codequick.script import Settings
𞺀=Settings.get_boolean
찺=Settings.get_string
from codequick.storage import PersistentDict
from resources.lib.utils import getTokenParams,getHeaders,isLoggedIn,𭪰 as ULogin,ﯶ as ULogout,check_addon,sendOTPV2,get_local_ip,getChannelHeaders,quality_to_enum,_setup,kodi_rpc,Monitor,getCachedChannels,getCachedDictionary,cleanLocalCache,getFeatured
from resources.lib.constants import GET_CHANNEL_URL,IMG_CATCHUP,PLAY_URL,IMG_CATCHUP_SHOWS,CATCHUP_SRC,M3U_SRC,EPG_SRC,M3U_CHANNEL,IMG_CONFIG,EPG_PATH
틹=M3U_CHANNEL.format
ⴷ=CATCHUP_SRC.format
import urlquick
𞤿=urlquick.cache_cleanup
𓏪=urlquick.post
𐭲=urlquick.get
from uuid import uuid4
from urllib.parse import urlencode
import inputstreamhelper
𐦱=inputstreamhelper.Helper
import json
from time import time,sleep
from datetime import datetime,timedelta,date
ﱮ=date.today
ﮦ=datetime.utcfromtimestamp
𐿡=datetime.fromtimestamp
import m3u8
𞹟=m3u8.loads
import requests
蠎=requests.request
import gzip
𞤍=gzip.compress
𣳰=gzip.𤟼
import xml.etree.ElementTree as ET
import os
덮=os.path
䜞=Monitor()
@ݐ
def 쀣(plugin):
 yield 𮖢(**{"label":"Featured","art":{"thumb":𨥻+"cms/TKSS_Carousal1.jpg","icon":𨥻+"cms/TKSS_Carousal1.jpg","fanart":𨥻+"cms/TKSS_Carousal1.jpg",},"callback":ﳭ("/resources/lib/main:show_featured")})
 for e in["Genres","Languages"]:
  yield 𮖢(**{"label":e,"callback":ﳭ("/resources/lib/main:show_listby"),"params":{"by":e}})
@ݐ
def ﰔ(plugin,𨝗=𞢙):
 for 𐢛 in getFeatured():
  if 𨝗:
   if 𐦒(𐢛.get("id",0))==𐦒(𨝗):
    𐼸=𐢛.get("data",[])
    for ﵙ in 𐼸:
     𐪂={"art":{"thumb":𨥻+ﵙ.get("episodePoster",""),"icon":𨥻+ﵙ.get("episodePoster",""),"fanart":𨥻+ﵙ.get("episodePoster",""),"clearart":IMG_CATCHUP+ﵙ.get("logoUrl",""),"clearlogo":IMG_CATCHUP+ﵙ.get("logoUrl",""),},"info":{'originaltitle':ﵙ.get("showname"),"tvshowtitle":ﵙ.get("showname"),"genre":ﵙ.get("showGenre"),"plot":ﵙ.get("description"),"episodeguide":ﵙ.get("episode_desc"),"episode":0 if ﵙ.get("episode_num")==-1 else ﵙ.get("episode_num"),"cast":ﵙ.get("starCast","").split(', '),"director":ﵙ.get("director"),"duration":ﵙ.get("duration")*60,"tag":ﵙ.get("keywords"),"mediatype":"movie" if ﵙ.get("channel_category_name")=="Movies" else "episode",}}
     if ﵙ.get("showStatus")=="Now":
      𐪂["label"]=𐪂["info"]["title"]=ﵙ.get("showname","")+" [COLOR red] [ LIVE ] [/COLOR]"
      𐪂["callback"]=𰙭
      𐪂["params"]={"channel_id":ﵙ.get("channel_id")}
      yield 𮖢(**𐪂)
     elif ﵙ.get("showStatus")=="future":
      륗=𐿡(𐦒(ﵙ.get("startEpoch",0)*.001)).strftime('    [ %I:%M %p -')+𐿡(𐦒(ﵙ.get("endEpoch",0)*.001)).strftime(' %I:%M %p ]   %a')
      𐪂["label"]=𐪂["info"]["title"]=ﵙ.get("showname","")+(" [COLOR green]%s[/COLOR]"%륗)
      𐪂["callback"]=""
      yield 𮖢(**𐪂)
     elif ﵙ.get("showStatus")=="catchup":
      륗=𐿡(𐦒(ﵙ.get("startEpoch",0)*.001)).strftime('    [ %I:%M %p -')+𐿡(𐦒(ﵙ.get("endEpoch",0)*.001)).strftime(' %I:%M %p ]   %a')
      𐪂["label"]=𐪂["info"]["title"]=ﵙ.get("showname","")+(" [COLOR yellow]%s[/COLOR]"%륗)
      𐪂["callback"]=𰙭
      𐪂["params"]={"channel_id":ﵙ.get("channel_id"),"showtime":ﵙ.get("showtime","").replace(":",""),"srno":𐿡(𐦒(ﵙ.get("startEpoch",0)*.001)).strftime('%Y%m%d'),"programId":ﵙ.get("srno",""),"begin":ﮦ(𐦒(ﵙ.get("startEpoch",0)*.001)).strftime('%Y%m%dT%H%M%S'),"end":ﮦ(𐦒(ﵙ.get("endEpoch",0)*.001)).strftime('%Y%m%dT%H%M%S')}
      yield 𮖢(**𐪂)
  else:
   yield 𮖢(**{"label":𐢛.get("name"),"art":{"thumb":𨥻+𐢛.get("data",[{}])[0].get("episodePoster"),"icon":𨥻+𐢛.get("data",[{}])[0].get("episodePoster"),"fanart":𨥻+𐢛.get("data",[{}])[0].get("episodePoster"),},"callback":ﳭ("/resources/lib/main:show_featured"),"params":{"id":𐢛.get("id")}})
@ݐ
def ﲔ(plugin,by):
 𐫤=getCachedDictionary()
 癨=𐫤.get("channelCategoryMapping")
 𐡱=𐫤.get("languageIdMapping")
 ﯧ=𐠄(𐡱.values())
 ﯧ.append("Extra")
 𐦿={"Genres":癨.values(),"Languages":ﯧ,}
 for 𐢛 in 𐦿[by]:
  𪪤=IMG_CONFIG[by].get(𐢛,{}).get("tvImg",""),
  𐺗=IMG_CONFIG[by].get(𐢛,{}).get("promoImg","")
  yield 𮖢(**{"label":𐢛,"art":{"thumb":𪪤,"icon":𪪤,"fanart":𐺗},"callback":ﳭ("/resources/lib/main:show_category"),"params":{"categoryOrLang":𐢛,"by":by}})
@ݐ
def ﻆ(plugin,ᰕ,by):
 𐼼=getCachedChannels()
 𐫤=getCachedDictionary()
 癨=𐫤.get("channelCategoryMapping")
 𐡱=𐫤.get("languageIdMapping")
 def 寗(x):
  ۀ=by.lower()[:-1]
  if ۀ=="genre":
   return 癨[𞺍(x.get("channelCategoryId"))]==ᰕ
  else:
   if(ᰕ=='Extra'):
    return 𞺍(x.get("channelLanguageId"))not in 𐡱.keys()
   else:
    if(𞺍(x.get("channelLanguageId"))not in 𐡱.keys()):
     return 飻
    return 𐡱[𞺍(x.get("channelLanguageId"))]==ᰕ
 for 𐢛 in 𐦭(寗,𐼼):
  if 𐢛.get("channelIdForRedirect"):
   continue
  𞺔=𮖢(**{"label":𐢛.get("channel_name"),"art":{"thumb":IMG_CATCHUP+𐢛.get("logoUrl"),"icon":IMG_CATCHUP+𐢛.get("logoUrl"),"fanart":IMG_CATCHUP+𐢛.get("logoUrl"),"clearlogo":IMG_CATCHUP+𐢛.get("logoUrl"),"clearart":IMG_CATCHUP+𐢛.get("logoUrl"),},"callback":𰙭,"params":{"channel_id":𐢛.get("channel_id")}})
  if 𐢛.get("isCatchupAvailable"):
   𞺔.context.container(䞿,"Catchup",0,𐢛.get("channel_id"))
  yield 𞺔
@ݐ
def 䞿(plugin,day,channel_id):
 𐼼=𐭲(ⴷ(day,channel_id),max_age=-1).json()
 𪽉=𣜤(𐼼['epg'],key=lambda show:show['startEpoch'],reverse=飻)
 𦌋='[COLOR red] [ LIVE ] [/COLOR]'
 for 𐢛 in 𪽉:
  ﰻ=𐦒(time()*1000)
  if not 𐢛['stbCatchupAvailable']or 𐢛['startEpoch']>ﰻ:
   continue
  ܘ=𐢛['startEpoch']<ﰻ and 𐢛['endEpoch']>ﰻ
  𦱭='   '+𦌋 if ܘ else 𐿡(𐦒(𐢛['startEpoch']*.001)).strftime('    [ %I:%M %p -')+𐿡(𐦒(𐢛['endEpoch']*.001)).strftime(' %I:%M %p ]   %a')
  yield 𮖢(**{"label":𐢛['showname']+𦱭,"art":{'thumb':𨥻+𐢛['episodePoster'],'icon':𨥻+𐢛['episodePoster'],'fanart':𨥻+𐢛['episodePoster'],},"callback":𰙭,"info":{'title':𐢛['showname']+𦱭,'originaltitle':𐢛['showname'],"tvshowtitle":𐢛['showname'],'genre':𐢛['showGenre'],'plot':𐢛['description'],"episodeguide":𐢛.get("episode_desc"),'episode':0 if 𐢛['episode_num']==-1 else 𐢛['episode_num'],'cast':𐢛['starCast'].split(', '),'director':𐢛['director'],'duration':𐢛['duration']*60,'tag':𐢛['keywords'],'mediatype':'episode',},"params":{"channel_id":𐢛.get("channel_id"),"showtime":𐢛.get("showtime","").replace(":",""),"srno":𐿡(𐦒(𐢛.get("startEpoch",0)*.001)).strftime('%Y%m%d'),"programId":𐢛.get("srno",""),"begin":ﮦ(𐦒(𐢛.get("startEpoch",0)*.001)).strftime('%Y%m%dT%H%M%S'),"end":ﮦ(𐦒(𐢛.get("endEpoch",0)*.001)).strftime('%Y%m%dT%H%M%S')}})
 if 𐦒(day)==0:
  for i in 𤨴(-1,-7,-1):
   𐳇='Yesterday' if i==- 1 else(ﱮ()+timedelta(days=i)).strftime('%A %d %B')
   yield 𮖢(**{"label":𐳇,"callback":ﳭ("/resources/lib/main:show_epg"),"params":{"day":i,"channel_id":channel_id}})
@ﶎ
@isLoggedIn
def 𰵓(plugin,dt=𞢙):
 ڵ=𐦱(dt.get("proto","mpd"),drm=dt.get("drm"))
 if ڵ.check_inputstream():
  쪍=dt.get("lUrl")and dt.get("lUrl").replace("{HEADERS}",urlencode(getHeaders())).replace("{TOKEN}",urlencode(getTokenParams()))
  𐠑={}
  if dt.get("default_logo"):
   𐠑['thumb']=𐠑['icon']=IMG_CATCHUP+ dt.get("default_logo")
  return Listitem().from_dict(**{"label":dt.get("label")or plugin._title,"art":𐠑 or 𞢙,"callback":dt.get("pUrl"),"properties":{"IsPlayable":𥿿,"inputstream":ڵ.inputstream_addon,"inputstream.adaptive.stream_headers":dt.get("hdrs"),"inputstream.adaptive.manifest_type":dt.get("proto","mpd"),"inputstream.adaptive.license_type":dt.get("drm"),"inputstream.adaptive.license_key":쪍,}})
@ﶎ
@isLoggedIn
def 𰙭(plugin,channel_id,showtime=𞢙,srno=𞢙,programId=𞢙,begin=𞢙,end=𞢙):
 ڵ=𐦱("mpd",drm="com.widevine.alpha")
 𡺥=ڵ.check_inputstream()
 if not 𡺥:
  return
 ڔ={"channel_id":𐦒(channel_id),"stream_type":"Seek"}
 䂰=飻
 if showtime and srno:
  䂰=𥿿
  ڔ["showtime"]=showtime
  ڔ["srno"]=srno
  ڔ["stream_type"]="Catchup"
  ڔ["programId"]=programId
  ڔ["begin"]=begin
  ڔ["end"]=end
  𐡇(𞺍(ڔ),lvl=𤿲)
 𐫡=getHeaders()
 𐫡['channelid']=𞺍(channel_id)
 𐫡['srno']=𞺍(uuid4())if "srno" not in ڔ else ڔ["srno"]
 𤿻=𓏪(GET_CHANNEL_URL,json=ڔ,headers=getChannelHeaders(),max_age=-1)
 𐼼=𤿻.json()
 𐠑={}
 ࣆ=𐼼.get("result","").split("?")[0].split('/')[-1]
 𐠑["thumb"]=𐠑["icon"]=IMG_CATCHUP+ ࣆ.replace(".m3u8",".png")
 𐤄="__hdnea__"+𐼼.get("result","").split("__hdnea__")[-1]
 𐫡['cookie']=𐤄
 沩=𐼼.get("result","")
 𞤸=찺("quality")
 𡐙="adaptive"
 if 𞤸=='Manual':
  𡐙="ask-quality"
 else:
  𐐅={}
  𐐅['user-agent']=𐫡['user-agent']
  𐐅['cookie']=𐤄
  ﵴ=𐭲(沩,headers=𐐅,max_age=-1,raise_for_status=𥿿)
  𞹏=ﵴ.text
  𘗅=𞹟(𞹏)
  if 𘗅.is_variant and(𘗅.version is 𞢙 or 𘗅.version<7):
   𐤶=quality_to_enum(𞤸,𐤥(𘗅.playlists))
   if 䂰:
    鬜=𘗅.playlists[𐤶].uri
    if "?" in 鬜:
     沩=沩.split("?")[0].replace(ࣆ,鬜)
    else:
     沩=沩.replace(ࣆ,鬜.split("?")[0])
    del 𐫡['cookie']
   else:
    沩=沩.replace(ࣆ,𘗅.playlists[𐤶].uri)
 𐡇(沩,lvl=𤿲)
 return Listitem().from_dict(**{"label":plugin._title,"art":𐠑,"callback":沩,"properties":{"IsPlayable":𥿿,"inputstream":"inputstream.adaptive",'inputstream.adaptive.stream_selection_type':𡐙,"inputstream.adaptive.chooser_resolution_secure_max":"4K","inputstream.adaptive.stream_headers":urlencode(𐫡),"inputstream.adaptive.manifest_type":"hls","inputstream.adaptive.license_key":"|"+urlencode(𐫡)+"|R{SSM}|",}})
@𞢢
def 𭪰(plugin):
 𐢙=Dialog().yesno("Login","Select Login Method",yeslabel="Keyboard",nolabel="WEB")
 if 𐢙==1:
  뗖=Dialog().yesno("Login","Select Login Type",yeslabel="OTP",nolabel="Password")
  if 뗖==1:
   ﱸ=찺("mobile")
   if not ﱸ or(𐤥(ﱸ)!=10):
    ﱸ=Dialog().numeric(0,"Enter your Jio mobile number")
   𓐘=sendOTPV2(ﱸ)
   if 𓐘:
    뻒("Login Error",𓐘)
    return
   蓟=Dialog().numeric(0,"Enter OTP")
   ﭟ(ﱸ,蓟,mode="otp")
  elif 뗖==0:
   ﱍ=keyboard("Enter your Jio mobile number or email")
   𐳇=keyboard("Enter your password",hidden=𥿿)
   ﭟ(ﱍ,𐳇)
 elif 𐢙==0:
  ﹲ=DialogProgress()
  ﹲ.create('JioTV','Visit [B]http://%s:48996/[/B] to login'%get_local_ip())
  for i in 𤨴(120):
   𥾁(1)
   with PersistentDict("headers")as db:
    𐫡=db.get("headers")
   if 𐫡 or ﹲ.iscanceled():
    break
   ﹲ.update(i)
  ﹲ.close()
@𞢢
def 𐳏(plugin):
 ﰰ='plugin.video.jiotv'
 𐢇=𐩳(ﰰ)
 𣀍=찺("mobile")
 ﱸ=Dialog().numeric(0,"Update Jio mobile number",𣀍)
 kodi_rpc('Addons.SetAddonEnabled',{'addonid':ﰰ,'enabled':飻})
 𐢇.setSetting('mobile',ﱸ)
 kodi_rpc('Addons.SetAddonEnabled',{'addonid':ﰰ,'enabled':𥿿})
 䜞.waitForAbort(1)
 뻒("Jio number set","")
@𞢢
def 𦸅(plugin):
 ﰰ='plugin.video.jiotv'
 kodi_rpc('Addons.SetAddonEnabled',{'addonid':ﰰ,'enabled':飻})
 䜞.waitForAbort(1)
 kodi_rpc('Addons.SetAddonEnabled',{'addonid':ﰰ,'enabled':𥿿})
 䜞.waitForAbort(1)
 뻒("All settings applied","")
@𞢢
def ﯶ(plugin):
 𩨵()
@𞢢
def 쯶(plugin,notify="yes"):
 𬒀=getCachedChannels()
 𐫤=getCachedDictionary()
 癨=𐫤.get("channelCategoryMapping")
 𐡱=𐫤.get("languageIdMapping")
 ﺑ="#EXTM3U x-tvg-url=\"%s\""%EPG_SRC
 for i,channel in 𬇄(𬒀):
  if(𞺍(channel.get("channelLanguageId"))not in 𐡱.keys()):
   㴬="Extra"
  else:
   㴬=𐡱[𞺍(channel.get("channelLanguageId"))]
  if(𞺍(channel.get("channelCategoryId"))not in 癨.keys()):
   𠃊="Extragenre"
  else:
   𠃊=癨[𞺍(channel.get("channelCategoryId"))]
  if not 𞺀(㴬):
   continue
  𞡇=㴬+";"+𠃊
  𓌛=PLAY_URL+ "channel_id={0}".format(channel.get("channel_id"))
  摾=""
  if channel.get("isCatchupAvailable"):
   摾=' catchup="vod" catchup-source="{0}channel_id={1}&showtime={{H}}{{M}}{{S}}&srno={{Y}}{{m}}{{d}}&programId={{catchup-id}}" catchup-days="7"'.format(PLAY_URL,channel.get("channel_id"))
  ﺑ+=틹(tvg_id=channel.get("channel_id"),channel_name=channel.get("channel_name"),group_title=𞡇,tvg_chno=𐦒(channel.get("channel_order",i))+1,tvg_logo=IMG_CATCHUP+channel.get("logoUrl",""),catchup=摾,play_url=𓌛,)
 with 𤟼(M3U_SRC,"w+")as f:
  f.write(ﺑ.replace(u'\xa0',' ').encode('utf-8').decode('utf-8'))
 if notify=="yes":
  뻒("JioTV","Playlist updated.")
@𞢢
def 𩽽(plugin):
 뻒("Please wait","Epg setup in progress")
 ﹲ=DialogProgress()
 ﹲ.create('Epg setup in progress')
 𩅴=찺("epgurl")
 if not 𩅴 or(𐤥(𩅴)<5):
  𩅴="https://cdn.jsdelivr.net/gh/mitthu786/tvepg/epg.xml.gz"
 𥺷={}
 𐫡={}
 𮚉=蠎("GET",𩅴,headers=𐫡,data=𥺷)
 with 𤟼(EPG_PATH,'wb')as f:
  f.write(𮚉.content)
 ﹲ.update(20)
 with 𣳰(EPG_PATH,'rb')as f:
  𐼸=f.read()
  ﶶ=𐼸.decode('utf-8')
  쀣=ET.fromstring(ﶶ)
 ﹲ.update(30)
 ﹲ.update(35)
 ﹲ.update(45)
 for 㸚 in 쀣.iterfind(".//programme"):
  ﺇ=㸚.find('icon')
  𐭪=ﺇ.get('src')
  糢=𐭪.rsplit('/',1)[-1]
  ﶷ=덮.splitext(糢)[0]
  㸚.set('catchup-id',ﶷ)
  𥑀=㸚.find('title')
  𥑀.text=𥑀.text.strip()
 ﹲ.update(60)
 𐳝='<?xml version="1.0" encoding="UTF-8"?>\n'
 𞡿='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n'
 ﷶ=𐳝.encode('UTF-8')+𞡿.encode('UTF-8')+ ET.tostring(쀣,encoding='UTF-8')
 𑩽=𞤍(ﷶ)
 ﹲ.update(80)
 with 𤟼(EPG_PATH,'wb')as f:
  f.write(𑩽)
 ﹲ.update(100)
 ﹲ.close()
 뻒("JioTV","Epg generated")
@𞢢
def 𐊺(plugin):
 𘈓("RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/m3ugen/)")
 㼒='pvr.iptvsimple'
 def ࠌ(𨝗,value):
  if 𐩳(㼒).getSetting(𨝗)!=value:
   𐩳(㼒).setSetting(𨝗,value)
 if check_addon(㼒):
  ࠌ("m3uPathType","0")
  ࠌ("m3uPath",M3U_SRC)
  ࠌ("epgPathType","1")
  ࠌ("epgUrl",EPG_SRC)
  ࠌ("catchupEnabled","true")
  ࠌ("catchupWatchEpgBeginBufferMins","0")
  ࠌ("catchupWatchEpgEndBufferMins","0")
 _setup(M3U_SRC,EPG_PATH)
@𞢢
def 𧟯(plugin):
 𞤿(-1)
 cleanLocalCache()
 뻒("Cache Cleaned","")
# Created by pyminifier (https://github.com/liftoff/pyminifier)
