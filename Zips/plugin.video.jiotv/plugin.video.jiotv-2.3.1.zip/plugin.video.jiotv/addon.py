from resources.lib import main
𞸕=main.𞸕
if __name__=="__main__":
 𞸕()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
