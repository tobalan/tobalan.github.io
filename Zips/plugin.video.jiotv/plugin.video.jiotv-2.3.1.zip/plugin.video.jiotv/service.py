from resources.lib import proxy
ݡ=Exception
뉋=True
ﶢ=proxy.ﶢ
from codequick import Script
𞠦=Script.DEBUG
𤋊=Script.log
from codequick.script import Settings
𪿎=Settings.get_boolean
from socketserver import ThreadingTCPServer
𐫏=ThreadingTCPServer.allow_reuse_address
import threading
𞺢=threading.Thread
from xbmc import Monitor,executebuiltin
from kodi_six import xbmcgui
ﭤ=xbmcgui.Dialog
def 𐼉(𭖭):
 try:
  𭖭.serve_forever()
 except ݡ as e:
  𤋊(e,lvl=𞠦)
  pass
𐫏=뉋
𞺳=48996
𭖭=ThreadingTCPServer(("",𞺳),ﶢ)
t=𞺢(target=𐼉,args=(𭖭,))
t.setDaemon(뉋)
t.start()
if not 𪿎("popup"):
 ﭤ().ok("JioTV Notification","Now you can create your custom playlist from BotAllen Dashboard. [CR]Find out more at [B]https://botallen.com/#dashboard[/B] [CR][CR]If you like this add-on then consider donating from [B]https://botallen.com/#donate[/B] [CR][CR]Github: [B]https://github.com/botallen/repository.botallen[/B] [CR]Discord: [B]https://botallen.com/discord[/B] [CR][CR][I]You can disable this popup from settings[/I]")
if 𪿎("m3ugen"):
 𐩹("RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/m3ugen/?notify=no)")
𐼰=Monitor()
while not 𐼰.abortRequested():
 if 𐼰.waitForAbort(10):
  𭖭.shutdown()
  𭖭.server_close()
  break
# Created by pyminifier (https://github.com/liftoff/pyminifier)
